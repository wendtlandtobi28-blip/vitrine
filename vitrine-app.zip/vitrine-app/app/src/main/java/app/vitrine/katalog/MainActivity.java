package app.vitrine.katalog;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Die Hülle der App: zeigt die mitgelieferte Oberfläche aus dem Ordner "assets" an.
 * Die App braucht kein Internet und fragt keine Berechtigungen ab.
 */
public class MainActivity extends Activity {

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int nachtmodus = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        boolean dunkel = nachtmodus == Configuration.UI_MODE_NIGHT_YES;

        webView = new WebView(this);
        webView.setBackgroundColor(getResources().getColor(R.color.hintergrund));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);

        WebSettings einstellungen = webView.getSettings();
        einstellungen.setJavaScriptEnabled(true);
        einstellungen.setDomStorageEnabled(true);
        einstellungen.setSupportZoom(false);
        einstellungen.setBuiltInZoomControls(false);
        einstellungen.setDisplayZoomControls(false);
        einstellungen.setTextZoom(100);
        // Die Oberfläche liest an dieser Kennung ab, ob sie hell oder dunkel erscheinen soll.
        einstellungen.setUserAgentString(einstellungen.getUserAgentString() + (dunkel ? " Vitrine/dunkel" : " Vitrine/hell"));

        webView.setWebViewClient(new WebViewClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        // Die Zurück-Taste schließt erst geöffnete Unterseiten, dann die App.
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
