# Vitrine

Ein App-Katalog zum Stöbern für Android: Schaufenster, Regale, Kategorien, Suche, Merkliste und eine Seite für jede App. Alle 30 Apps sind erfundene Beispiele. Die App braucht kein Internet und keine Berechtigungen.

## APK bauen lassen (ohne Computer)

1. Auf github.com ein neues Repository anlegen, zum Beispiel `vitrine`. Dabei „Add a README file“ anhaken.
2. Im Repository auf **Actions** gehen und **set up a workflow yourself** wählen. Den vorgeschlagenen Text löschen, den Inhalt von `workflow.yml` einfügen und mit **Commit changes** speichern.
3. Im Repository **Add file → Upload files** wählen, `vitrine-app.zip` hochladen und mit **Commit changes** speichern.
4. Nach etwa fünf Minuten liegt unter **Releases** die Datei `Vitrine.apk`. Herunterladen, öffnen, installieren.

Für eine neue Version lädst du einfach eine neue `vitrine-app.zip` hoch. Die neue APK lässt sich über die alte installieren.

## Was wo liegt

- `app/src/main/assets/index.html`: die komplette Oberfläche mit allen Apps, Texten und Farben.
- `app/src/main/java/.../MainActivity.java`: die Android-Hülle, die diese Oberfläche anzeigt.
- `app/src/main/res/`: App-Name, App-Symbol und die Farben der Systemleisten.
- `apk-bauen.sh`: baut die APK auf GitHub und legt sie als Release ab.

## Gut zu wissen

- Der Signierschlüssel `app/vitrine.keystore` liegt mit im Projekt, damit sich Updates ohne Deinstallieren einspielen lassen. Für eine Veröffentlichung in einem Store bräuchte die App einen eigenen, geheimen Schlüssel.
- Die eingebetteten Schriften und ihre Lizenzen stehen in `LIZENZEN.txt`.
