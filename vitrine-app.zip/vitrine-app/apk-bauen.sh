#!/usr/bin/env bash
# Baut die Vitrine-APK auf einem GitHub-Rechner und legt sie als Release ab.
# Der Workflow ruft dieses Skript auf. Von Hand ist nichts zu tun.
set -euo pipefail
cd "$(dirname "$0")"

GRADLE_VERSION="8.7"
TEMP="${RUNNER_TEMP:-/tmp}"

echo "== 1/4 Java wählen"
for KANDIDAT in "${JAVA_HOME_17_X64:-}" "${JAVA_HOME_21_X64:-}"; do
  if [ -n "$KANDIDAT" ] && [ -x "$KANDIDAT/bin/java" ]; then
    export JAVA_HOME="$KANDIDAT"
    export PATH="$JAVA_HOME/bin:$PATH"
    break
  fi
done
java -version

echo "== 2/4 Android-Bausteine bereitstellen"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/usr/local/lib/android/sdk}}"
export ANDROID_HOME="$SDK" ANDROID_SDK_ROOT="$SDK"
SDKMANAGER="$SDK/cmdline-tools/latest/bin/sdkmanager"
if [ -d "$SDK" ] && [ ! -w "$SDK" ]; then
  sudo chmod -R a+rwX "$SDK" || true
fi
if [ -x "$SDKMANAGER" ]; then
  (yes || true) | "$SDKMANAGER" --licenses > /dev/null 2>&1 || true
  (yes || true) | "$SDKMANAGER" "platforms;android-34" "build-tools;34.0.0" > /dev/null \
    || echo "Hinweis: sdkmanager meldet einen Fehler. Der Build lädt Fehlendes selbst nach."
fi

echo "== 3/4 APK bauen"
if [ -n "${VITRINE_GRADLE:-}" ]; then
  GRADLE="$VITRINE_GRADLE"
else
  if [ ! -x "$TEMP/gradle-$GRADLE_VERSION/bin/gradle" ]; then
    curl -fsSL --retry 3 -o "$TEMP/gradle.zip" "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip"
    unzip -q -o "$TEMP/gradle.zip" -d "$TEMP"
  fi
  GRADLE="$TEMP/gradle-$GRADLE_VERSION/bin/gradle"
fi
"$GRADLE" --no-daemon --console=plain assembleRelease

APK="app/build/outputs/apk/release/app-release.apk"
if [ ! -f "$APK" ]; then
  echo "Die APK wurde nicht erzeugt."
  exit 1
fi
cp "$APK" Vitrine.apk

echo "== 4/4 Release anlegen"
NUMMER="${GITHUB_RUN_NUMBER:-1}"
MARKE="v1.0.$NUMMER"
if [ -n "${GITHUB_REPOSITORY:-}" ] && command -v gh > /dev/null 2>&1; then
  if gh release view "$MARKE" --repo "$GITHUB_REPOSITORY" > /dev/null 2>&1; then
    gh release upload "$MARKE" Vitrine.apk --repo "$GITHUB_REPOSITORY" --clobber
  else
    gh release create "$MARKE" Vitrine.apk --repo "$GITHUB_REPOSITORY" \
      --title "Vitrine 1.0.$NUMMER" \
      --notes "Vitrine.apk herunterladen und auf dem Gerät öffnen, um die App zu installieren." \
      --latest
  fi
  LINK="https://github.com/$GITHUB_REPOSITORY/releases/latest/download/Vitrine.apk"
  echo "Fertig: $LINK"
  if [ -n "${GITHUB_STEP_SUMMARY:-}" ]; then
    echo "### Vitrine.apk ist fertig" >> "$GITHUB_STEP_SUMMARY"
    echo "[APK herunterladen]($LINK)" >> "$GITHUB_STEP_SUMMARY"
  fi
fi
